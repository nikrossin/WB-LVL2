Creating a Boot Image with Hex55 Utility

- Use the hex conversion utility (hex55.exe) revision 4.3.3 or later. 
- To create a bootimage:
1. Copy the files in the "hex_converter" directory to a local directory.
2. Open the command line and navigate to that directory.
3. Type "hex55 EVM_Sample.cmd" ==> this will convert "EVM_Sample.out" to "EVM_Sample.bin". 

Please modify the input and output file name (in EVM_Sample.cmd) if you need. 
