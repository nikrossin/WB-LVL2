#include "array/array_scale_lin.c"
#include "array/concat.c"
#include "array/decimate.c"
#include "array/decimate_cmplx.c"
#include "array/find_nearest.c"
#include "array/flipip.c"
#include "array/flipip_cmplx.c"
#include "array/linspace.c"
#include "array/logspace.c"
#include "array/ones.c"
#include "array/sum.c"
#include "array/sum_sqr.c"

#include "array/verif.c"
#include "array/verif_cmplx.c"



