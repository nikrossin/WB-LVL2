
#include "gnuplot/gnuplot_close.c"
#include "gnuplot/gnuplot_cmd.c"
#include "gnuplot/gnuplot_create.c"
#include "gnuplot/gnuplot_open.c"