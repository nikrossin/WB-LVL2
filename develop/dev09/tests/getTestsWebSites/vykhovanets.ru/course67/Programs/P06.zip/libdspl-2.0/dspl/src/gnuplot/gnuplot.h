#ifndef GNUPLOT_H
#define GNUPLOT_H




#endif