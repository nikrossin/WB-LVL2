
#include "inout/addlog.c"
#include "inout/dspl_info.c"
#include "inout/readbin.c"
#include "inout/writebin.c"
#include "inout/writetxt.c"
#include "inout/writetxt_cmplx.c"
#include "inout/writetxt_int.c"
#include "inout/writetxt_3d.c"
#include "inout/writetxt_3dline.c"
#include "inout/writetxt_cmplx_re.c"
#include "inout/writetxt_cmplx_im.c"

#include "inout/verif_data_gen.c"
#include "inout/verif_str.c"
#include "inout/verif_str_cmplx.c"







