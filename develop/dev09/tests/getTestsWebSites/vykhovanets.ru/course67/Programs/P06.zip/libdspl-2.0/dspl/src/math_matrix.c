

#include "math_matrix/matrix_eig_cmplx.c"
#include "math_matrix/matrix_eye.c"
#include "math_matrix/matrix_eye_cmplx.c"
#include "math_matrix/matrix_mul.c"
#include "math_matrix/matrix_pinv.c"
#include "math_matrix/matrix_print.c"
#include "math_matrix/matrix_print_cmplx.c"
#include "math_matrix/matrix_svd.c"
#include "math_matrix/matrix_transpose.c"
#include "math_matrix/matrix_transpose_cmplx.c"
#include "math_matrix/matrix_transpose_hermite.c"
#include "math_matrix/vector_dot.c"






