

#include "math_poly/poly_z2a_cmplx.c"
#include "math_poly/polyroots.c"
#include "math_poly/polyval.c"
#include "math_poly/polyval_cmplx.c"


#include "math_poly/cheby_poly1.c"
#include "math_poly/cheby_poly2.c"
