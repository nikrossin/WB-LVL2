
#include "math_stat/find_max_abs.c"
#include "math_stat/histogram.c"
#include "math_stat/histogram_norm.c"
#include "math_stat/mean.c"
#include "math_stat/mean_cmplx.c"
#include "math_stat/minmax.c"
#include "math_stat/stat_std.c"
#include "math_stat/stat_std_cmplx.c"

#include "math_stat/xcorr.c"