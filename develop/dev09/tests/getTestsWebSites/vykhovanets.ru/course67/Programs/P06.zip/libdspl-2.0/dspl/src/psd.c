


#include "psd/psd_bartlett.c"
#include "psd/psd_bartlett_cmplx.c"
#include "psd/psd_periodogram.c"
#include "psd/psd_periodogram_cmplx.c"
#include "psd/psd_welch.c"
#include "psd/psd_welch_cmplx.c"













